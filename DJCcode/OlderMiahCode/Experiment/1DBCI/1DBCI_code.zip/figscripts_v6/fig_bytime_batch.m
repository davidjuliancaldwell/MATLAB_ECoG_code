
for num = 1:7
    fig_bytime;
    clearvars -except num
    close all;
end
