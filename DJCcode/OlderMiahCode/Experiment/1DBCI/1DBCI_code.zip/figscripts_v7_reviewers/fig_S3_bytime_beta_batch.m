
for num = 2:7
    fig_S3_bytime_beta;
    clearvars -except num
    close all;
end
