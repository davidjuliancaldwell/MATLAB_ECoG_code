
for num = 2:7
    fig_bytime;
    clearvars -except num
    close all;
end
