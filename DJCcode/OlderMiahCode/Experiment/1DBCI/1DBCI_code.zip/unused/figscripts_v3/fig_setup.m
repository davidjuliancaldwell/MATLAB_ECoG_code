% generic setup script for all analyses scripts
tcs;

subjids = {
    '26cb98'
    '04b3d5'
    '38e116'
    '4568f4'
    '30052b'
    'fc9643'
    'mg'
    };

figOutDir = fullfile(myGetenv('output_dir'), '1DBCI', 'figs');